const randomElement = (array) =>{
    return array[Math.floor(Math.random() * array.length)]
}

export {randomElement};